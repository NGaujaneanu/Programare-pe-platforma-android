package com.application.app.modules.meniucatel2.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel2Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtAre10kgEste: String? =
      MyApp.getInstance().resources.getString(R.string.msg_are_10kg_este)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtLara4AniC: String? =
      MyApp.getInstance().resources.getString(R.string.msg_lara_4_ani_c)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaMai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_mai)

)
