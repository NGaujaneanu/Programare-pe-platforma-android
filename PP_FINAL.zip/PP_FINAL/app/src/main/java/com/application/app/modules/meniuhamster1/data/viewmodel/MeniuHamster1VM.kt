package com.application.app.modules.meniuhamster1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuhamster1.`data`.model.MeniuHamster1Model
import org.koin.core.KoinComponent

public class MeniuHamster1VM : ViewModel(), KoinComponent {
  public val meniuHamster1Model: MutableLiveData<MeniuHamster1Model> =
      MutableLiveData(MeniuHamster1Model())

  public var navArguments: Bundle? = null
}
