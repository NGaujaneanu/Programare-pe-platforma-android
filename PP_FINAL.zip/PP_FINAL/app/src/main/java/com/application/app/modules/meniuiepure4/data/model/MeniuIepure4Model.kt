package com.application.app.modules.meniuiepure4.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuIepure4Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtDonezIepurePi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_donez_iepure_pi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtIepurila1An: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iepurila_1_an)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtIepureRasaBe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iepure_rasa_be)

)
