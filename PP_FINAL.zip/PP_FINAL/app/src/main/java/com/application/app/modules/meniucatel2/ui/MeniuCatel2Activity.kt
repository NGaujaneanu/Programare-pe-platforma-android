package com.application.app.modules.meniucatel2.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuCatel2Binding
import com.application.app.modules.meniucatel2.`data`.viewmodel.MeniuCatel2VM
import com.application.app.modules.meniucatel3.ui.MeniuCatel3Activity
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuCatel2Activity :
    BaseActivity<ActivityMeniuCatel2Binding>(R.layout.activity_meniu_catel2) {
  private val viewModel: MeniuCatel2VM by viewModels<MeniuCatel2VM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuCatel2VM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imageXiconpng271.setOnClickListener {
      val destIntent = MeniuCatel3Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageCheckmarkflat.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw1.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_CATEL2ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuCatel2Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
