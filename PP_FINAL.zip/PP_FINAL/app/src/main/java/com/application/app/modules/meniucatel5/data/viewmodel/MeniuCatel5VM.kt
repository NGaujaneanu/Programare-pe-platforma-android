package com.application.app.modules.meniucatel5.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel5.`data`.model.MeniuCatel5Model
import org.koin.core.KoinComponent

public class MeniuCatel5VM : ViewModel(), KoinComponent {
  public val meniuCatel5Model: MutableLiveData<MeniuCatel5Model> =
      MutableLiveData(MeniuCatel5Model())

  public var navArguments: Bundle? = null
}
