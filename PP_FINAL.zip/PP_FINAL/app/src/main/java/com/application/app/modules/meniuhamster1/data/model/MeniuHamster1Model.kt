package com.application.app.modules.meniuhamster1.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuHamster1Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtCiobiARamasF: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ciobi_a_ramas_f)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCiobi6Luni: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ciobi_6_luni)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtHamsterRasa: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_hamster_rasa)

)
