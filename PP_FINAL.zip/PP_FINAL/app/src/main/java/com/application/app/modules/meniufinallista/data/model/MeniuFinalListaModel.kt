package com.application.app.modules.meniufinallista.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuFinalListaModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtAcesteaSuntTo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_acestea_sunt_to)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtApasatiAiciPe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_apasati_aici_pe)

)
