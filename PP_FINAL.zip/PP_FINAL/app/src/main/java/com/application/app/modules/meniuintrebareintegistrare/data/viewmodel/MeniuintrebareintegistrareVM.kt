package com.application.app.modules.meniuintrebareintegistrare.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuintrebareintegistrare.`data`.model.MeniuintrebareintegistrareModel
import org.koin.core.KoinComponent

public class MeniuintrebareintegistrareVM : ViewModel(), KoinComponent {
  public val meniuintrebareintegistrareModel: MutableLiveData<MeniuintrebareintegistrareModel> =
      MutableLiveData(MeniuintrebareintegistrareModel())

  public var navArguments: Bundle? = null
}
