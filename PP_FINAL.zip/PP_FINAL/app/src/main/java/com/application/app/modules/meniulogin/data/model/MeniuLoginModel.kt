package com.application.app.modules.meniulogin.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuLoginModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtIntroducetiDat: String? =
      MyApp.getInstance().resources.getString(R.string.msg_introduceti_dat)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtAdresa: String? = MyApp.getInstance().resources.getString(R.string.lbl_adresa)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtTelefon: String? = MyApp.getInstance().resources.getString(R.string.lbl_telefon)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtAutentificare: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_autentificare2)

)
