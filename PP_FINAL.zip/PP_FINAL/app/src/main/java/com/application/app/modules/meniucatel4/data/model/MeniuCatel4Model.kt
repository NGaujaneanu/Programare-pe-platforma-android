package com.application.app.modules.meniucatel4.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel4Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtPufuletMascul: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pufulet_mascul)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPufi2LuniB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pufi_2_luni_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaMai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_mai)

)
