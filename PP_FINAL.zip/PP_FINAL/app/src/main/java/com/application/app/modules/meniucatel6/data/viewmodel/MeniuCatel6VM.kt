package com.application.app.modules.meniucatel6.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel6.`data`.model.MeniuCatel6Model
import org.koin.core.KoinComponent

public class MeniuCatel6VM : ViewModel(), KoinComponent {
  public val meniuCatel6Model: MutableLiveData<MeniuCatel6Model> =
      MutableLiveData(MeniuCatel6Model())

  public var navArguments: Bundle? = null
}
