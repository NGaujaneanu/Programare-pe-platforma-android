package com.application.app.modules.meniuprincipal.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuPrincipalModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtAdoptaUnAnim: String? =
      MyApp.getInstance().resources.getString(R.string.msg_adopta_un_anima)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtIesire: String? = MyApp.getInstance().resources.getString(R.string.lbl_iesire)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtAutentificare: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_autentificare)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPP: String? = MyApp.getInstance().resources.getString(R.string.lbl_p_p)

)
