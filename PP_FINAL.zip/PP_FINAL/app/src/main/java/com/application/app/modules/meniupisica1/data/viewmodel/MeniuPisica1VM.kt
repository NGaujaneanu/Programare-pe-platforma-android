package com.application.app.modules.meniupisica1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniupisica1.`data`.model.MeniuPisica1Model
import org.koin.core.KoinComponent

public class MeniuPisica1VM : ViewModel(), KoinComponent {
  public val meniuPisica1Model: MutableLiveData<MeniuPisica1Model> =
      MutableLiveData(MeniuPisica1Model())

  public var navArguments: Bundle? = null
}
