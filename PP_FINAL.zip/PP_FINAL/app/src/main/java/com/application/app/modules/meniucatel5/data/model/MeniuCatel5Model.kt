package com.application.app.modules.meniucatel5.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel5Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtEsteFoarteSoc: String? =
      MyApp.getInstance().resources.getString(R.string.msg_este_foarte_soc)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCookie4Ani: String? =
      MyApp.getInstance().resources.getString(R.string.msg_cookie_4_ani)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaYor: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_yor)

)
