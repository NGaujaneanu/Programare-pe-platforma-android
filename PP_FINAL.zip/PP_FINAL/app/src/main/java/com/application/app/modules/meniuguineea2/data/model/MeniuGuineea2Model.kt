package com.application.app.modules.meniuguineea2.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuGuineea2Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtUsorDeIngriji: String? =
      MyApp.getInstance().resources.getString(R.string.msg_usor_de_ingriji)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtKevin1AnS: String? =
      MyApp.getInstance().resources.getString(R.string.msg_kevin_1_an_s)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtHamsterRasa: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_hamster_rasa)

)
