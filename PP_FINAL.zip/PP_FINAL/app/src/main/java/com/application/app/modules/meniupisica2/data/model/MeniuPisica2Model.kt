package com.application.app.modules.meniupisica2.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuPisica2Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtLuluAFostAlu: String? =
      MyApp.getInstance().resources.getString(R.string.msg_lulu_a_fost_alu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPisicutaRasa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pisicuta_rasa2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtLulu1LunaP: String? =
      MyApp.getInstance().resources.getString(R.string.msg_lulu_1_luna_p)

)
