package com.application.app.modules.appnavigation.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class AppNavigationModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtAppNavigation: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_app_navigation)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCheckYourAppsUIFromTheBelowDemoScreensOfYourApp: String? =
      MyApp.getInstance().resources.getString(R.string.msg_check_your_app)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuPrincipal: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_principal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuIncepere: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_incepere)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuLogIn: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_login)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuIntrebareIntegistrare: String? =
      MyApp.getInstance().resources.getString(R.string.msg_meniuintrebarei)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuInformaatii: String? =
      MyApp.getInstance().resources.getString(R.string.msg_meniu_informaat)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel1: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel_1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuHamster1: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_hamster1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuHamster2: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_hamster2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuIepure2: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_iepure2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuIepure4: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_iepure4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel7: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel7)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel4: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel3: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuIepure3: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_iepure3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuGuineea1: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_guineea1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel2: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuIepure1: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_iepure1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel6: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel6)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuCatel5: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_catel5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuPisica1: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_pisica1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuPisica2: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_pisica2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuPisica5: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_pisica_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuPisica3: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_pisica3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuPisica4: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_pisica_4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuGuineea2: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniu_guineea2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuFinalLista: String? =
      MyApp.getInstance().resources.getString(R.string.msg_meniu_final_lis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMeniuConfirmare: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_meniuconfirmare)

)
