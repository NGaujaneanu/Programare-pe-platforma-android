package com.application.app.modules.appnavigation.ui

import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityAppNavigationBinding
import com.application.app.modules.appnavigation.`data`.viewmodel.AppNavigationVM
import com.application.app.modules.meniucatel1.ui.MeniuCatel1Activity
import com.application.app.modules.meniucatel2.ui.MeniuCatel2Activity
import com.application.app.modules.meniucatel3.ui.MeniuCatel3Activity
import com.application.app.modules.meniucatel4.ui.MeniuCatel4Activity
import com.application.app.modules.meniucatel5.ui.MeniuCatel5Activity
import com.application.app.modules.meniucatel6.ui.MeniuCatel6Activity
import com.application.app.modules.meniucatel7.ui.MeniuCatel7Activity
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniufinallista.ui.MeniuFinalListaActivity
import com.application.app.modules.meniuguineea1.ui.MeniuGuineea1Activity
import com.application.app.modules.meniuguineea2.ui.MeniuGuineea2Activity
import com.application.app.modules.meniuhamster1.ui.MeniuHamster1Activity
import com.application.app.modules.meniuhamster2.ui.MeniuHamster2Activity
import com.application.app.modules.meniuiepure1.ui.MeniuIepure1Activity
import com.application.app.modules.meniuiepure2.ui.MeniuIepure2Activity
import com.application.app.modules.meniuiepure3.ui.MeniuIepure3Activity
import com.application.app.modules.meniuiepure4.ui.MeniuIepure4Activity
import com.application.app.modules.meniuincepere.ui.MeniuIncepereActivity
import com.application.app.modules.meniuinformaatii.ui.MeniuInformaatiiActivity
import com.application.app.modules.meniuintrebareintegistrare.ui.MeniuintrebareintegistrareActivity
import com.application.app.modules.meniulogin.ui.MeniuLoginActivity
import com.application.app.modules.meniupisica1.ui.MeniuPisica1Activity
import com.application.app.modules.meniupisica2.ui.MeniuPisica2Activity
import com.application.app.modules.meniupisica3.ui.MeniuPisica3Activity
import com.application.app.modules.meniupisica4.ui.MeniuPisica4Activity
import com.application.app.modules.meniupisica5.ui.MeniuPisica5Activity
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class AppNavigationActivity :
    BaseActivity<ActivityAppNavigationBinding>(R.layout.activity_app_navigation) {
  private val viewModel: AppNavigationVM by viewModels<AppNavigationVM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appNavigationVM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.linearMeniuIntrebareIntegistrare.setOnClickListener {
      val destIntent = MeniuintrebareintegistrareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuHamster1.setOnClickListener {
      val destIntent = MeniuHamster1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel2.setOnClickListener {
      val destIntent = MeniuCatel2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuGuineea1.setOnClickListener {
      val destIntent = MeniuGuineea1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuIepure4.setOnClickListener {
      val destIntent = MeniuIepure4Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuConfirmare.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuGuineea2.setOnClickListener {
      val destIntent = MeniuGuineea2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuPrincipal.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel1.setOnClickListener {
      val destIntent = MeniuCatel1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuIepure3.setOnClickListener {
      val destIntent = MeniuIepure3Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel5.setOnClickListener {
      val destIntent = MeniuCatel5Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuPisica2.setOnClickListener {
      val destIntent = MeniuPisica2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuIepure2.setOnClickListener {
      val destIntent = MeniuIepure2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuPisica3.setOnClickListener {
      val destIntent = MeniuPisica3Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuPisica4.setOnClickListener {
      val destIntent = MeniuPisica4Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel3.setOnClickListener {
      val destIntent = MeniuCatel3Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuIncepere.setOnClickListener {
      val destIntent = MeniuIncepereActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel4.setOnClickListener {
      val destIntent = MeniuCatel4Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuHamster2.setOnClickListener {
      val destIntent = MeniuHamster2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuPisica5.setOnClickListener {
      val destIntent = MeniuPisica5Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuFinalLista.setOnClickListener {
      val destIntent = MeniuFinalListaActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuInformaatii.setOnClickListener {
      val destIntent = MeniuInformaatiiActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel7.setOnClickListener {
      val destIntent = MeniuCatel7Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuPisica1.setOnClickListener {
      val destIntent = MeniuPisica1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuLogIn.setOnClickListener {
      val destIntent = MeniuLoginActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuIepure1.setOnClickListener {
      val destIntent = MeniuIepure1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMeniuCatel6.setOnClickListener {
      val destIntent = MeniuCatel6Activity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "APP_NAVIGATION_ACTIVITY"
  }
}
