package com.application.app.modules.meniuprincipal.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuprincipal.`data`.model.MeniuPrincipalModel
import org.koin.core.KoinComponent

public class MeniuPrincipalVM : ViewModel(), KoinComponent {
  public val meniuPrincipalModel: MutableLiveData<MeniuPrincipalModel> =
      MutableLiveData(MeniuPrincipalModel())

  public var navArguments: Bundle? = null
}
