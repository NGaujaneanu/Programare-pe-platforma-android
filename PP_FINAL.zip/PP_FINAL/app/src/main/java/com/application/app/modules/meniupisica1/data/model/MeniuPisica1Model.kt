package com.application.app.modules.meniupisica1.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuPisica1Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtMaiaAAjunsLa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_maia_a_ajuns_la)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPisicutaRasa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pisicuta_rasa)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMaia3Saptama: String? =
      MyApp.getInstance().resources.getString(R.string.msg_maia_3_saptama)

)
