package com.application.app.modules.meniucatel1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel1.`data`.model.MeniuCatel1Model
import org.koin.core.KoinComponent

public class MeniuCatel1VM : ViewModel(), KoinComponent {
  public val meniuCatel1Model: MutableLiveData<MeniuCatel1Model> =
      MutableLiveData(MeniuCatel1Model())

  public var navArguments: Bundle? = null
}
