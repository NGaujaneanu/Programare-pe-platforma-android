package com.application.app.modules

import android.R
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.application.app.modules.meniuinformaatii.ui.MeniuInformaatiiActivity


class Informatii : AppCompatActivity() {


    }

