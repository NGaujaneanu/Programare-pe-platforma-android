package com.application.app.modules.meniuhamster2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuhamster2.`data`.model.MeniuHamster2Model
import org.koin.core.KoinComponent

public class MeniuHamster2VM : ViewModel(), KoinComponent {
  public val meniuHamster2Model: MutableLiveData<MeniuHamster2Model> =
      MutableLiveData(MeniuHamster2Model())

  public var navArguments: Bundle? = null
}
