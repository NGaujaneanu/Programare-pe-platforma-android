package com.application.app.modules.meniucatel1.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuCatel1Binding
import com.application.app.modules.meniucatel1.`data`.viewmodel.MeniuCatel1VM
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniupisica1.ui.MeniuPisica1Activity
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuCatel1Activity :
    BaseActivity<ActivityMeniuCatel1Binding>(R.layout.activity_meniu_catel_1) {
  private val viewModel: MeniuCatel1VM by viewModels<MeniuCatel1VM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuCatel1VM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imageXiconpng271.setOnClickListener {
      val destIntent = MeniuPisica1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageCheckmarkflat.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_CATEL1ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuCatel1Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
