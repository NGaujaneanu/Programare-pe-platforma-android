package com.application.app.modules.meniuprincipal.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuPrincipalBinding
import com.application.app.modules.meniuincepere.ui.MeniuIncepereActivity
import com.application.app.modules.meniuintrebareintegistrare.ui.MeniuintrebareintegistrareActivity
import com.application.app.modules.meniuprincipal.`data`.viewmodel.MeniuPrincipalVM
import kotlin.String
import kotlin.Unit
import kotlin.system.exitProcess

public class MeniuPrincipalActivity :
    BaseActivity<ActivityMeniuPrincipalBinding>(R.layout.activity_meniu_principal) {
  private val viewModel: MeniuPrincipalVM by viewModels<MeniuPrincipalVM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuPrincipalVM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.txtAdoptaUnAnim.setOnClickListener {
      val destIntent = MeniuIncepereActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtAutentificare.setOnClickListener {
      val destIntent = MeniuintrebareintegistrareActivity.getIntent(this, null )
      startActivity(destIntent)
    }
    binding.txtIesire.setOnClickListener {
      finish()
      exitProcess(0)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_PRINCIPAL_ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuPrincipalActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}