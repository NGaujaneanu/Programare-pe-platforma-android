package com.application.app.modules.meniuinformaatii.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.view.View
import android.widget.EditText
import androidx.activity.viewModels
import androidx.versionedparcelable.VersionedParcelize
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuInformaatiiBinding
import com.application.app.modules.Informatii
import com.application.app.modules.meniuincepere.ui.MeniuIncepereActivity
import com.application.app.modules.meniuinformaatii.data.viewmodel.MeniuInformaatiiVM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity

class MeniuInformaatiiActivity:
    BaseActivity<ActivityMeniuInformaatiiBinding>(R.layout.activity_meniu_informaatii) {
  private val viewModel: MeniuInformaatiiVM by viewModels<MeniuInformaatiiVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuInformaatiiVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtConfirm.setOnClickListener {
      val destIntent = MeniuIncepereActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun getData(): Unit {
    val locatie = findViewById<View>(R.id.InputLocatie) as EditText
    val locatie1 = locatie.toString()

    val nume = findViewById<View>(R.id.InputNume) as EditText
    val nume1 = nume.toString()

    val prenume = findViewById<View>(R.id.InputPrenume) as EditText
    val prenume1 = prenume.toString()

    val varsta = findViewById<View>(R.id.InputVarsta) as EditText
    val varsta1 = varsta.toString()

    val adresa = findViewById<View>(R.id.InputAdresa) as EditText
    val adresa1 = adresa.toString()

    val telefon = findViewById<View>(R.id.InputTelefon) as EditText
    val telefon1 = telefon.toString()

  }


  companion object {

    const val TAG: String = "MENIU_INFORMAATII_ACTIVITY"

    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuInformaatiiActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}

