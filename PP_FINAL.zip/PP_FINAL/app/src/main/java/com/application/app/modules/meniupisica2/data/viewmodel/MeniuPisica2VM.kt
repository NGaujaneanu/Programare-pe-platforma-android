package com.application.app.modules.meniupisica2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniupisica2.`data`.model.MeniuPisica2Model
import org.koin.core.KoinComponent

public class MeniuPisica2VM : ViewModel(), KoinComponent {
  public val meniuPisica2Model: MutableLiveData<MeniuPisica2Model> =
      MutableLiveData(MeniuPisica2Model())

  public var navArguments: Bundle? = null
}
