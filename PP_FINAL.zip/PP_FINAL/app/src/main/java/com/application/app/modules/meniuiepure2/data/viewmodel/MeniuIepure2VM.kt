package com.application.app.modules.meniuiepure2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuiepure2.`data`.model.MeniuIepure2Model
import org.koin.core.KoinComponent

public class MeniuIepure2VM : ViewModel(), KoinComponent {
  public val meniuIepure2Model: MutableLiveData<MeniuIepure2Model> =
      MutableLiveData(MeniuIepure2Model())

  public var navArguments: Bundle? = null
}
