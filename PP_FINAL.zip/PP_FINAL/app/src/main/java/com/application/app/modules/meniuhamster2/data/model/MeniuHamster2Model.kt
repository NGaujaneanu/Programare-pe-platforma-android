package com.application.app.modules.meniuhamster2.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuHamster2Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtUnAnimalutPer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_un_animalut_per)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtKari3AniB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_kari_3_ani_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtHamsterRasa: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_hamster_rasa)

)
