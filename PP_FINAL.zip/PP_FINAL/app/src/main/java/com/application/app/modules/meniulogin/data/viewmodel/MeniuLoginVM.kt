package com.application.app.modules.meniulogin.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniulogin.`data`.model.MeniuLoginModel
import org.koin.core.KoinComponent

public class MeniuLoginVM : ViewModel(), KoinComponent {
  public val meniuLoginModel: MutableLiveData<MeniuLoginModel> = MutableLiveData(MeniuLoginModel())

  public var navArguments: Bundle? = null
}
