package com.application.app.modules.meniucatel7.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel7.`data`.model.MeniuCatel7Model
import org.koin.core.KoinComponent

public class MeniuCatel7VM : ViewModel(), KoinComponent {
  public val meniuCatel7Model: MutableLiveData<MeniuCatel7Model> =
      MutableLiveData(MeniuCatel7Model())

  public var navArguments: Bundle? = null
}
