package com.application.app.modules.meniuguineea1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuguineea1.`data`.model.MeniuGuineea1Model
import org.koin.core.KoinComponent

public class MeniuGuineea1VM : ViewModel(), KoinComponent {
  public val meniuGuineea1Model: MutableLiveData<MeniuGuineea1Model> =
      MutableLiveData(MeniuGuineea1Model())

  public var navArguments: Bundle? = null
}
