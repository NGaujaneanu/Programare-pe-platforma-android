package com.application.app.modules.meniufinallista.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuFinalListaBinding
import com.application.app.modules.meniufinallista.`data`.viewmodel.MeniuFinalListaVM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuFinalListaActivity :
    BaseActivity<ActivityMeniuFinalListaBinding>(R.layout.activity_meniu_final_lista) {
  private val viewModel: MeniuFinalListaVM by viewModels<MeniuFinalListaVM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuFinalListaVM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.txtApasatiAiciPe.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_FINAL_LISTA_ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuFinalListaActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
