package com.application.app.modules.meniucatel3.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel3.`data`.model.MeniuCatel3Model
import org.koin.core.KoinComponent

public class MeniuCatel3VM : ViewModel(), KoinComponent {
  public val meniuCatel3Model: MutableLiveData<MeniuCatel3Model> =
      MutableLiveData(MeniuCatel3Model())

  public var navArguments: Bundle? = null
}
