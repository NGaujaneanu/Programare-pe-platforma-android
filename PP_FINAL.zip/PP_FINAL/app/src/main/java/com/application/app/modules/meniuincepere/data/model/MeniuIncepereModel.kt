package com.application.app.modules.meniuincepere.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuIncepereModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtIncepeti: String? = MyApp.getInstance().resources.getString(R.string.lbl_incepeti)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPentruAPutea: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pentru_a_putea)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtDacaDoritiSa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_daca_doriti_sa)

)
