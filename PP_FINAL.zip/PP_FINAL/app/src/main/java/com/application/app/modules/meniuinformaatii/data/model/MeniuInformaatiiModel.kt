package com.application.app.modules.meniuinformaatii.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuInformaatiiModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtDatePersonale: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_date_personale)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtVarsta: String? = MyApp.getInstance().resources.getString(R.string.lbl_varsta)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtLocatie: String? = MyApp.getInstance().resources.getString(R.string.lbl_locatie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtNume: String? = MyApp.getInstance().resources.getString(R.string.lbl_nume)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPrenume: String? = MyApp.getInstance().resources.getString(R.string.lbl_prenume)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtAdresa: String? = MyApp.getInstance().resources.getString(R.string.lbl_adresa)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtConfirm: String? = MyApp.getInstance().resources.getString(R.string.lbl_confirm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtTelefon: String? = MyApp.getInstance().resources.getString(R.string.lbl_telefon)



)
