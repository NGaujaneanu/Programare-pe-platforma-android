package com.application.app.modules.meniuiepure3.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuIepure3Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtIepurePiticCa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iepure_pitic_ca)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPerry4Ani: String? =
      MyApp.getInstance().resources.getString(R.string.msg_perry_4_ani)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtIepureRasaFu: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iepure_rasa_fu)

)
