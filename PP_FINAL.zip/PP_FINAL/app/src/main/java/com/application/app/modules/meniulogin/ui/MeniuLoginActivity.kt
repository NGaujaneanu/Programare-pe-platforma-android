package com.application.app.modules.meniulogin.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuLoginBinding
import com.application.app.modules.meniuincepere.ui.MeniuIncepereActivity
import com.application.app.modules.meniulogin.`data`.viewmodel.MeniuLoginVM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuLoginActivity :
    BaseActivity<ActivityMeniuLoginBinding>(R.layout.activity_meniu_login) {
  private val viewModel: MeniuLoginVM by viewModels<MeniuLoginVM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuLoginVM = viewModel
  }


  public override fun setUpClicks(): Unit {
    binding.txtAutentificare.setOnClickListener {
      val destIntent = MeniuIncepereActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun getLogin(): Unit {
    val adresa_login  = findViewById<View>(R.id.InputLoginAdresa) as EditText
    val adresa_login1 = adresa_login.toString()
    val telefon_login  = findViewById<View>(R.id.InputLoginTel) as EditText
    val telefon_login1 = telefon_login.toString()
  }
  public companion object {
    public const val TAG: String = "MENIU_LOGIN_ACTIVITY"


    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuLoginActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
