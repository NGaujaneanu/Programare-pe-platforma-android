package com.application.app.modules.meniucatel6.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel6Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtPuiDeTalieMi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pui_de_talie_mi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMickey3An: String? =
      MyApp.getInstance().resources.getString(R.string.msg_mickey_3_an)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaBic: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_bic)

)
