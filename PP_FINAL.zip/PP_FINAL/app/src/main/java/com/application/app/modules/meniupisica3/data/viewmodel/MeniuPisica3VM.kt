package com.application.app.modules.meniupisica3.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniupisica3.`data`.model.MeniuPisica3Model
import org.koin.core.KoinComponent

public class MeniuPisica3VM : ViewModel(), KoinComponent {
  public val meniuPisica3Model: MutableLiveData<MeniuPisica3Model> =
      MutableLiveData(MeniuPisica3Model())

  public var navArguments: Bundle? = null
}
