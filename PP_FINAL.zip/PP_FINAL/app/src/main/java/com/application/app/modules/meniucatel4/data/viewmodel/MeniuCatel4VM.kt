package com.application.app.modules.meniucatel4.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel4.`data`.model.MeniuCatel4Model
import org.koin.core.KoinComponent

public class MeniuCatel4VM : ViewModel(), KoinComponent {
  public val meniuCatel4Model: MutableLiveData<MeniuCatel4Model> =
      MutableLiveData(MeniuCatel4Model())

  public var navArguments: Bundle? = null
}
