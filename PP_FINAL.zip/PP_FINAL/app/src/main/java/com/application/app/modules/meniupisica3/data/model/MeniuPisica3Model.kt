package com.application.app.modules.meniupisica3.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuPisica3Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtStelutaEOPis: String? =
      MyApp.getInstance().resources.getString(R.string.msg_steluta_e_o_pis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPisicutaRasa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pisicuta_rasa3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtSteluta3Sapt: String? =
      MyApp.getInstance().resources.getString(R.string.msg_steluta_3_sapt)

)
