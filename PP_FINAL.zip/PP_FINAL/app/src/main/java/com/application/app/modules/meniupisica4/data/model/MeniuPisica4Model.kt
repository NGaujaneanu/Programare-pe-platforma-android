package com.application.app.modules.meniupisica4.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuPisica4Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtCuBlanaMeaLu: String? =
      MyApp.getInstance().resources.getString(R.string.msg_cu_blana_mea_lu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPisicutaRasa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pisicuta_rasa4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMaia8Saptama: String? =
      MyApp.getInstance().resources.getString(R.string.msg_maia_8_saptama)

)
