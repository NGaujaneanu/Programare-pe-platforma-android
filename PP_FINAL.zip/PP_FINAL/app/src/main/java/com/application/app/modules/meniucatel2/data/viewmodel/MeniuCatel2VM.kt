package com.application.app.modules.meniucatel2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniucatel2.`data`.model.MeniuCatel2Model
import org.koin.core.KoinComponent

public class MeniuCatel2VM : ViewModel(), KoinComponent {
  public val meniuCatel2Model: MutableLiveData<MeniuCatel2Model> =
      MutableLiveData(MeniuCatel2Model())

  public var navArguments: Bundle? = null
}
