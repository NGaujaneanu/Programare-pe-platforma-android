package com.application.app.modules.meniuguineea2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuguineea2.`data`.model.MeniuGuineea2Model
import org.koin.core.KoinComponent

public class MeniuGuineea2VM : ViewModel(), KoinComponent {
  public val meniuGuineea2Model: MutableLiveData<MeniuGuineea2Model> =
      MutableLiveData(MeniuGuineea2Model())

  public var navArguments: Bundle? = null
}
