package com.application.app.modules.meniuconfirmare.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuconfirmare.`data`.model.MeniuconfirmareModel
import org.koin.core.KoinComponent

public class MeniuconfirmareVM : ViewModel(), KoinComponent {
  public val meniuconfirmareModel: MutableLiveData<MeniuconfirmareModel> =
      MutableLiveData(MeniuconfirmareModel())

  public var navArguments: Bundle? = null
}
