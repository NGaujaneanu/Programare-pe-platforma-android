package com.application.app.modules.meniupisica5.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuPisica5Binding
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniuguineea1.ui.MeniuGuineea1Activity
import com.application.app.modules.meniupisica5.`data`.viewmodel.MeniuPisica5VM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuPisica5Activity :
    BaseActivity<ActivityMeniuPisica5Binding>(R.layout.activity_meniu_pisica_5) {
  private val viewModel: MeniuPisica5VM by viewModels<MeniuPisica5VM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuPisica5VM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imagePngclipartpaw1.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageCheckmarkflat.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageXiconpng271.setOnClickListener {
      val destIntent = MeniuGuineea1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_PISICA5ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuPisica5Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
