package com.application.app.modules.meniuiepure4.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuiepure4.`data`.model.MeniuIepure4Model
import org.koin.core.KoinComponent

public class MeniuIepure4VM : ViewModel(), KoinComponent {
  public val meniuIepure4Model: MutableLiveData<MeniuIepure4Model> =
      MutableLiveData(MeniuIepure4Model())

  public var navArguments: Bundle? = null
}
