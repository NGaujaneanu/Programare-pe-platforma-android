package com.application.app.modules.meniucatel3.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuCatel3Binding
import com.application.app.modules.meniucatel3.`data`.viewmodel.MeniuCatel3VM
import com.application.app.modules.meniucatel4.ui.MeniuCatel4Activity
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuCatel3Activity :
    BaseActivity<ActivityMeniuCatel3Binding>(R.layout.activity_meniu_catel3) {
  private val viewModel: MeniuCatel3VM by viewModels<MeniuCatel3VM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuCatel3VM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imageXiconpng271.setOnClickListener {
      val destIntent = MeniuCatel4Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageCheckmarkflat.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw1.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_CATEL3ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuCatel3Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
