package com.application.app.modules.meniucatel3.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel3Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelDeDoiAn: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_de_doi_an)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMisu2AniB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_misu_2_ani_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaMai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_mai)

)
