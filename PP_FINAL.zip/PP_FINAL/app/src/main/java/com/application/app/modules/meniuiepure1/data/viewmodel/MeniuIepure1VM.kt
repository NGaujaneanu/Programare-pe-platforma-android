package com.application.app.modules.meniuiepure1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuiepure1.`data`.model.MeniuIepure1Model
import org.koin.core.KoinComponent

public class MeniuIepure1VM : ViewModel(), KoinComponent {
  public val meniuIepure1Model: MutableLiveData<MeniuIepure1Model> =
      MutableLiveData(MeniuIepure1Model())

  public var navArguments: Bundle? = null
}
