package com.application.app.modules.meniupisica4.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniupisica4.`data`.model.MeniuPisica4Model
import org.koin.core.KoinComponent

public class MeniuPisica4VM : ViewModel(), KoinComponent {
  public val meniuPisica4Model: MutableLiveData<MeniuPisica4Model> =
      MutableLiveData(MeniuPisica4Model())

  public var navArguments: Bundle? = null
}
