package com.application.app.modules.meniuguineea1.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuGuineea1Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtNemoEsteUnPo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nemo_este_un_po)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtNemo4AniB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nemo_4_ani_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPorcusorDeGui: String? =
      MyApp.getInstance().resources.getString(R.string.msg_porcusor_de_gui)

)
