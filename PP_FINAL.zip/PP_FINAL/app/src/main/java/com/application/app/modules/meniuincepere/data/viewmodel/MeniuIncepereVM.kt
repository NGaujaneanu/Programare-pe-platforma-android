package com.application.app.modules.meniuincepere.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuincepere.`data`.model.MeniuIncepereModel
import org.koin.core.KoinComponent

public class MeniuIncepereVM : ViewModel(), KoinComponent {
  public val meniuIncepereModel: MutableLiveData<MeniuIncepereModel> =
      MutableLiveData(MeniuIncepereModel())

  public var navArguments: Bundle? = null
}
