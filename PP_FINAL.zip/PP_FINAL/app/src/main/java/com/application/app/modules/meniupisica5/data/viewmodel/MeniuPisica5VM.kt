package com.application.app.modules.meniupisica5.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniupisica5.`data`.model.MeniuPisica5Model
import org.koin.core.KoinComponent

public class MeniuPisica5VM : ViewModel(), KoinComponent {
  public val meniuPisica5Model: MutableLiveData<MeniuPisica5Model> =
      MutableLiveData(MeniuPisica5Model())

  public var navArguments: Bundle? = null
}
