package com.application.app.modules.meniuhamster1.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuHamster1Binding
import com.application.app.modules.meniucatel5.ui.MeniuCatel5Activity
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniuhamster1.`data`.viewmodel.MeniuHamster1VM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuHamster1Activity :
    BaseActivity<ActivityMeniuHamster1Binding>(R.layout.activity_meniu_hamster1) {
  private val viewModel: MeniuHamster1VM by viewModels<MeniuHamster1VM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuHamster1VM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imageXiconpng271.setOnClickListener {
      val destIntent = MeniuCatel5Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageCheckmarkflat.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_HAMSTER1ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuHamster1Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
