package com.application.app.modules.meniupisica5.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuPisica5Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtPnMaiIeri: String? =
      MyApp.getInstance().resources.getString(R.string.msg_p_n_mai_ieri)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtPisicutaRasa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pisicuta_rasa3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtKira2Saptama: String? =
      MyApp.getInstance().resources.getString(R.string.msg_kira_2_saptama)

)
