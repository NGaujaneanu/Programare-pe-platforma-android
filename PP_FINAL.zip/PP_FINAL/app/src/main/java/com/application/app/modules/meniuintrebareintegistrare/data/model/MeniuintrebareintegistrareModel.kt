package com.application.app.modules.meniuintrebareintegistrare.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuintrebareintegistrareModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtAvetiUnContE: String? =
      MyApp.getInstance().resources.getString(R.string.msg_aveti_un_cont_e)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtDa: String? = MyApp.getInstance().resources.getString(R.string.lbl_da)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtNuDorescSaM: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nu_doresc_sa_m)

)
