package com.application.app.modules.meniuincepere.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuIncepereBinding
import com.application.app.modules.meniucatel1.ui.MeniuCatel1Activity
import com.application.app.modules.meniuincepere.`data`.viewmodel.MeniuIncepereVM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuIncepereActivity :
    BaseActivity<ActivityMeniuIncepereBinding>(R.layout.activity_meniu_incepere) {
  private val viewModel: MeniuIncepereVM by viewModels<MeniuIncepereVM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuIncepereVM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imagePngclipartpaw.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtIncepeti.setOnClickListener {
      val destIntent = MeniuCatel1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_INCEPERE_ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuIncepereActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
