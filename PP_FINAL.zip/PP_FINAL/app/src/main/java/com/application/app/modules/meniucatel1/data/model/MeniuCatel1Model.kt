package com.application.app.modules.meniucatel1.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel1Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtSaraEsteOCat: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sara_este_o_cat)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtSara4AniB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sara_4_ani_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaTer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_ter)

)
