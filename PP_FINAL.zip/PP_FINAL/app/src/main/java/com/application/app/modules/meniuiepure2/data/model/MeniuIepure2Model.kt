package com.application.app.modules.meniuiepure2.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuIepure2Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtIepureRasaNe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iepure_rasa_ne)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtRilaEsteUnIe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rila_este_un_ie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtRila1AniB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rila_1_ani_b)

)
