package com.application.app.modules.meniupisica3.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityMeniuPisica3Binding
import com.application.app.modules.meniucatel2.ui.MeniuCatel2Activity
import com.application.app.modules.meniuconfirmare.ui.MeniuconfirmareActivity
import com.application.app.modules.meniupisica3.`data`.viewmodel.MeniuPisica3VM
import com.application.app.modules.meniuprincipal.ui.MeniuPrincipalActivity
import kotlin.String
import kotlin.Unit

public class MeniuPisica3Activity :
    BaseActivity<ActivityMeniuPisica3Binding>(R.layout.activity_meniu_pisica3) {
  private val viewModel: MeniuPisica3VM by viewModels<MeniuPisica3VM>()

  public override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.meniuPisica3VM = viewModel
  }

  public override fun setUpClicks(): Unit {
    binding.imageXiconpng271.setOnClickListener {
      val destIntent = MeniuCatel2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageCheckmarkflat.setOnClickListener {
      val destIntent = MeniuconfirmareActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imagePngclipartpaw1.setOnClickListener {
      val destIntent = MeniuPrincipalActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  public companion object {
    public const val TAG: String = "MENIU_PISICA3ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MeniuPisica3Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
