package com.application.app.modules.meniuinformaatii.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuinformaatii.`data`.model.MeniuInformaatiiModel
import org.koin.core.KoinComponent

public class MeniuInformaatiiVM : ViewModel(), KoinComponent {
  public val meniuInformaatiiModel: MutableLiveData<MeniuInformaatiiModel> =
      MutableLiveData(MeniuInformaatiiModel())

  public var navArguments: Bundle? = null
}
