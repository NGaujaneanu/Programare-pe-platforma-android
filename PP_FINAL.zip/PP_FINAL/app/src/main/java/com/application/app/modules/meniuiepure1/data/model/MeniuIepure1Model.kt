package com.application.app.modules.meniuiepure1.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuIepure1Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtBunnyAFostAd: String? =
      MyApp.getInstance().resources.getString(R.string.msg_bunny_a_fost_ad)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtBunny1AnB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_bunny_1_an_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtIepurasRasaH: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iepuras_rasa_h)

)
