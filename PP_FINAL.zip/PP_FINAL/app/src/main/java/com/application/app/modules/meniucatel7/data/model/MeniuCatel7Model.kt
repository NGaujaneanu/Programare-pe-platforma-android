package com.application.app.modules.meniucatel7.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuCatel7Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtRexEsteUnC: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rex_este_un_c)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtRex4AniOl: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rex_4_ani_ol)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtCatelRasaMai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catel_rasa_mai)

)
