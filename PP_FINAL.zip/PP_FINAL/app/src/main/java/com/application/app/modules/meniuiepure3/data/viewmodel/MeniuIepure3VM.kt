package com.application.app.modules.meniuiepure3.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniuiepure3.`data`.model.MeniuIepure3Model
import org.koin.core.KoinComponent

public class MeniuIepure3VM : ViewModel(), KoinComponent {
  public val meniuIepure3Model: MutableLiveData<MeniuIepure3Model> =
      MutableLiveData(MeniuIepure3Model())

  public var navArguments: Bundle? = null
}
