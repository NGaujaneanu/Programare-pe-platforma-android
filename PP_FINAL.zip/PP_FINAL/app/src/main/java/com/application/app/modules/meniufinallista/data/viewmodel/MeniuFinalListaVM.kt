package com.application.app.modules.meniufinallista.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.meniufinallista.`data`.model.MeniuFinalListaModel
import org.koin.core.KoinComponent

public class MeniuFinalListaVM : ViewModel(), KoinComponent {
  public val meniuFinalListaModel: MutableLiveData<MeniuFinalListaModel> =
      MutableLiveData(MeniuFinalListaModel())

  public var navArguments: Bundle? = null
}
