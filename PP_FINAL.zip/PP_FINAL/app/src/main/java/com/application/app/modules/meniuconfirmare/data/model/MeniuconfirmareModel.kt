package com.application.app.modules.meniuconfirmare.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class MeniuconfirmareModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtVaMultumimPen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_va_multumim_pen)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtAlegereaDumnea: String? =
      MyApp.getInstance().resources.getString(R.string.msg_alegerea_dumnea)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtIesire: String? = MyApp.getInstance().resources.getString(R.string.lbl_iesire2)

)
